﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;
using Oracle.DataAccess.Client;
using EscolaFutebol.Properties;


namespace EscolaFutebol
{
     
    public class ConnectionFactory{
        static ConnectionFactory(){
              
        }
        //String de conexão criada na Settings do projeto

        private OleDbConnection conn = new OleDbConnection(@"Provider=ODP.NET;DATA SOURCE=localhost:1521/xe;USER ID=SYSTEM;PASSWORD=larissalinda123");

        public OleDbConnection getConection(){
            return conn;
        }
        public void OpenConnection(){
            conn.Open();
        }

        public void CloseConnection(){
           conn.Close();
        }

        public void Authenticate(string usuario,string password){
            bool ck=false;
            try
            {
                string user = usuario;
                string pass =password;

                string qr = "SELECT COUNT (Id) FROM UserList WHERE @NOME='"+user+ " ' @SENHA=' "+pass+" ' " ;

                OleDbDataAdapter oda = new OleDbDataAdapter(qr, conn);
                OleDbCommand oCmd = new OleDbCommand(qr,conn);

                oCmd.Parameters.Add("@Nome", OracleDbType.Varchar2).Value = user;
                oCmd.Parameters.Add("@SENHA",OracleDbType.Varchar2).Value=pass;

                OpenConnection();

                
                int v;
                v = (int) oCmd.ExecuteScalar();
                if (v > 0) {
                    MessageBox.Show("Bem Vindo: " + user + " \n Agora você terá acesso ás funcionalidades do sistema \n Obrigado por utilizar nosso sistema :D");
                    ck = true;
                    CheckIn(ck);
                }
                else{
                    MessageBox.Show("Erro ao logar");
                }


            }
            catch (Exception e)
            {
                MessageBox.Show("Erro ao lugar no banco: "+e);
            }
        }

        public bool CheckIn(bool ck){
            return ck;
        }


    }
}
